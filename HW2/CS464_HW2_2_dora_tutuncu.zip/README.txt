In this zip file for HW2 of the CS464, the report can be found in the repor.pdf file.
The code for the complete homework is available under the document CS464_HW2_2_dora_tutuncu.py file.

This code was written using the Google Colab software, using Python.
The script is available in .py format.

The necessary csv datasets were obtained using my own Google Drive directory folder containing the 
datasets for the assignment. To run the same code, only the directory must be changed accordingly.

The terminal command, as already written in the code is:
>> from google.colab import drive
>> drive.mount('/content/gdrive')

with the directory specified as:
>> !ls /content/gdrive/My\ Drive/Dora/Bilkent/CS464/HW1 # Use YOUR OWN DIRECTORY!!

where files can be extracted, using the following, with the "root" variable being required to change
according to the directory:

>> import os
>> root = '/content/gdrive/My Drive/Dora/Bilkent/CS464/HW1'

Running the entire program in the same order it is written is sufficient to get all the necessary outputs.
Note that some dataframes were shown using the display() function of pandas. This could also be changed to print().
Other specific parts have been adressed in the code via comments.


